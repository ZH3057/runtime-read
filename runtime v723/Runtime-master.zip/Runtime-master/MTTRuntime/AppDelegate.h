//
//  AppDelegate.h
//  MTTRuntime
//
//  Created by LiuChuanan on 2019/4/8.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


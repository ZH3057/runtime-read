//
//  Person.h
//  MTTRuntime
//
//  Created by LiuChuanan on 2019/4/12.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Person : NSObject

- (void)name;

@end

NS_ASSUME_NONNULL_END

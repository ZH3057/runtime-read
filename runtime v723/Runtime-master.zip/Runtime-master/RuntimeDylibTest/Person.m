

//
//  Person.m
//  MTTRuntime
//
//  Created by LiuChuanan on 2019/4/12.
//

#import "Person.h"

@implementation Person

- (void)name {
    NSLog(@"name");
}

@end
